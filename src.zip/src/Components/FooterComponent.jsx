const Footer = () => {
  return (
    <div>
      <footer className="footer">
        <span className="text-muted">
          Copyright @2021-present CDAC-ACTS. Students All rights reserved.
        </span>
      </footer>
    </div>
  );
};

export default Footer;
